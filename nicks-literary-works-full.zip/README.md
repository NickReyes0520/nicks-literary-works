
# Nick’s Literary Works (Minimal Build-Ready Scaffold)

This minimal repository boots a Next.js 14 App Router site so Vercel can deploy successfully.

## Quick Start

```bash
npm install
npm run dev
```

You'll see a basic home page. Replace this scaffold with the full code from your Canvas when ready.

**NOTE:** This repo only includes essential files to pass Vercel build checks.
