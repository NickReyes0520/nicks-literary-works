
// app/page.js
export default function Home() {
  return (
    <main style={{padding:'2rem'}}>
      <h2>Welcome to Nick’s Literary Works</h2>
      <p>Stay tuned: the full bookstore is coming soon!</p>
    </main>
  );
}
