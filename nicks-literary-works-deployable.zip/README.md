# Nick’s Literary Works — Minimal Deployable Scaffold

This repo is a **build‑passing Next.js 14 project**. Deploy to Vercel first, then replace with full code.

## Local

```bash
npm install
npm run dev
```

## Deploy

1. Push to GitHub
2. Import into Vercel → Deploy
3. Replace scaffold with bookstore code, commit, push — redeploys automatically.
