export default function Home() {
  return (
    <main style={{padding:'2rem'}}>
      <h2>Welcome to Nick’s Literary Works</h2>
      <p>This scaffold deploys successfully on Vercel. Swap in your full site code next.</p>
    </main>
  );
}
